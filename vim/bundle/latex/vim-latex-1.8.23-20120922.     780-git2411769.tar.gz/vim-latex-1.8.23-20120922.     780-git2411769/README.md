# vim-LaTeX

http://sourceforge.net/projects/vim-latex/files

## Why?

Because I want to be able to easily update this suite of tools without using
Subversion and because Sourceforge suck at supporting git!

## Updates

I'll do my best to keep this repo stable and up-to-date but if there's an
update available that I haven't spotted please do let me know.
